tnr34
=====

Totally Not Rule34 - A Simple, Fapable javascript rule34.paheal.net viewer.

I have no idea why I made this.

Requires CROS to be disabled-- until I use an iframe.

Node-webkit can be used to package it, with chromium-args: "--disable-web-security"

or, chrome --disable-web-security and run it locally.
